# GB Non-Domestic Flexibility Explorer

A static, client-side dashboard for the revised GB non-domestic consumer-led flexibility model.

## Run locally

Open `index.html` through a local web server (recommended rather than double-clicking):
- Python: `python -m http.server 8000`
- Then visit `http://localhost:8000`

## Publish with GitHub Pages

1. Create a **public** GitHub repository, e.g. `gb-clf-explorer`.
2. Upload the contents of this folder to the repository root.
3. In GitHub: **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will publish the site at:
   `https://YOUR-USERNAME.github.io/gb-clf-explorer/`

GitHub Pages is static hosting, so no server or Power BI account is required.

## Dashboard controls

- Sector: All / Industrial / Commercial
- Archetype
- End-use
- Potential: Technical / Economic
- Maximum hurdle cost: £150–£1,000/MWh
- Click a DNO on the map to focus the dashboard
- URL hash preserves the current filter state

## Model scope

DNO → Sector → Archetype → End-use → Technical Flex MW → Hurdle Cost → Economic Flex MW

There is deliberately no achievable-potential layer.

## DNO geography

The primary DNO map layer is the official NESO GB DNO Licence Areas GeoJSON:
https://www.neso.energy/data-portal/gis-boundaries-gb-dno-license-areas/gb_dno_licence_areas_20240503_with_geojson

NESO states that the GeoJSON uses EPSG:27700 (OSGB 1936 / British National Grid). The dashboard attempts to load this source directly in the browser. If browser CORS prevents it, the dashboard gracefully falls back to DNO centroid points.

## Data

`data/data.json` contains the dashboard-ready dataset:
- DNO
- Sector
- Archetype
- End-use
- Technical Flex MW
- Central Hurdle Cost (£/MWh)
- Economic Flex MW

The current screening dataset contains 3,780 rows and reconciles to approximately 4.033 GW technical flexibility and 3.900 GW economic flexibility at £500/MWh.

## Licence / attribution

DNO geography is sourced from NESO. Base map tiles are from OpenStreetMap contributors. The CLF analytical dataset is a project output and should be updated whenever the underlying model changes.
